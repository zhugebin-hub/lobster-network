export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

// 登录跳转到本地 /login 页面
export const getLoginUrl = () => {
  return `${window.location.origin}/login`;
};
