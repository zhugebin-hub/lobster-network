/**
 * 初始化题库 - 添加示例题目
 */

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const QUESTIONS_FILE = path.join(DATA_DIR, 'questions.json');

// 确保数据目录存在
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// 示例题目数据
const sampleQuestions = [
  {
    category: '道教理论',
    question: '《道德经》的作者是谁？',
    options: ['A. 庄子', 'B. 老子', 'C. 列子', 'D. 文子'],
    answer: 'B',
    explanation: '《道德经》相传为老子（李耳）所著，是道家哲学的核心经典。',
    difficulty: 1,
    created_at: new Date().toISOString()
  },
  {
    category: '道教理论',
    question: '道教的核心教义是什么？',
    options: ['A. 因果报应', 'B. 道法自然', 'C. 四谛八正道', 'D. 原罪救赎'],
    answer: 'B',
    explanation: '道教以"道"为最高信仰，主张道法自然、无为而治。',
    difficulty: 1,
    created_at: new Date().toISOString()
  },
  {
    category: '道教历史',
    question: '道教正式形成于哪个朝代？',
    options: ['A. 汉朝', 'B. 唐朝', 'C. 宋朝', 'D. 明朝'],
    answer: 'A',
    explanation: '道教正式形成于东汉时期，张道陵创立五斗米道是道教组织化的重要标志。',
    difficulty: 2,
    created_at: new Date().toISOString()
  },
  {
    category: '法律法规',
    question: '《宗教事务条例》自哪一年开始施行？',
    options: ['A. 2004 年', 'B. 2005 年', 'C. 2006 年', 'D. 2007 年'],
    answer: 'B',
    explanation: '《宗教事务条例》于 2004 年 11 月 30 日公布，自 2005 年 3 月 1 日起施行。',
    difficulty: 2,
    created_at: new Date().toISOString()
  },
  {
    category: '法律法规',
    question: '我国宪法规定公民享有什么自由？',
    options: ['A. 言论自由', 'B. 宗教信仰自由', 'C. 集会自由', 'D. 以上都是'],
    answer: 'D',
    explanation: '我国宪法第 35 条、第 36 条规定了公民的言论、集会、宗教信仰等自由。',
    difficulty: 1,
    created_at: new Date().toISOString()
  },
  {
    category: '道教修炼',
    question: '内丹修炼的三个主要阶段是？',
    options: ['A. 炼精化气、炼气化神、炼神还虚', 'B. 炼气化精、炼神化气、炼虚还神', 'C. 炼神化精、炼气化神、炼虚还道', 'D. 炼精化神、炼气化虚、炼神还道'],
    answer: 'A',
    explanation: '内丹修炼的三个阶段：炼精化气（初关）、炼气化神（中关）、炼神还虚（上关）。',
    difficulty: 3,
    created_at: new Date().toISOString()
  },
  {
    category: '道教文化',
    question: '道教的标志性符号是？',
    options: ['A. 十字架', 'B. 太极图', 'C. 新月', 'D. 六芒星'],
    answer: 'B',
    explanation: '太极图是道教的标志性符号，象征阴阳对立统一的哲学思想。',
    difficulty: 1,
    created_at: new Date().toISOString()
  },
  {
    category: '道教文化',
    question: '《道藏》是什么？',
    options: ['A. 道教经典总集', 'B. 道教历史书', 'C. 道教修炼手册', 'D. 道教音乐集'],
    answer: 'A',
    explanation: '《道藏》是道教经典的总集，收录了道教的各种经典、论著、科仪等。',
    difficulty: 2,
    created_at: new Date().toISOString()
  }
];

// 写入数据
fs.writeFileSync(QUESTIONS_FILE, JSON.stringify(sampleQuestions, null, 2));

console.log(`✅ 成功添加 ${sampleQuestions.length} 道示例题目`);
console.log('📚 题库分类：道教理论、道教历史、法律法规、道教修炼、道教文化');
console.log('');
console.log('🚀 启动系统：npm start');
console.log('🌐 访问地址：http://localhost:3000');
